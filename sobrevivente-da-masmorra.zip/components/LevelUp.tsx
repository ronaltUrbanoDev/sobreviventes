
import React from 'react';
import { Character, GameMode, PlayerStatKey } from '../types';

interface LevelUpProps {
    player: Character;
    playerData: Character; // The raw data before effective stats calculation
    basePlayerStats: Character;
    points: number;
    gains: { xp: number; gold: number; interest?: number };
    onAttributeIncrease: (stat: PlayerStatKey) => void;
    onAttributeDecrease: (stat: PlayerStatKey) => void;
    onContinue: () => void;
    autoDistributeEnabled: boolean;
    onToggleAutoDistribute: () => void;
    isRetrying?: boolean;
    t: (key: any, params?: Record<string, string | number>) => string;
    gameMode: GameMode;
}

const AttributeControl: React.FC<{ label: string; value: number; icon: string; onIncrease: () => void; onDecrease: () => void; increaseDisabled: boolean; decreaseDisabled: boolean; t: (key: any) => string; }> = ({ label, value, icon, onIncrease, onDecrease, increaseDisabled, decreaseDisabled, t }) => (
    <div className="flex items-center justify-between bg-gray-700 p-3 rounded-lg">
        <div className="flex items-center gap-3">
            <span className="text-2xl">{icon}</span>
            <div>
                <span className="font-bold text-gray-300">{label}</span>
                <p className="text-xl font-semibold text-white">{Math.round(value)}</p>
            </div>
        </div>
        <div className="flex items-center gap-2">
             <button onClick={onDecrease} disabled={decreaseDisabled} className="w-9 h-9 bg-red-600 text-white font-bold rounded-full text-2xl flex items-center justify-center hover:bg-red-700 transition-transform transform hover:scale-110 disabled:bg-gray-500 disabled:cursor-not-allowed disabled:transform-none" aria-label={`${t('decrease')} ${label}`}> - </button>
            <button onClick={onIncrease} disabled={increaseDisabled} className="w-9 h-9 bg-green-500 text-white font-bold rounded-full text-2xl flex items-center justify-center hover:bg-green-600 transition-transform transform hover:scale-110 disabled:bg-gray-500 disabled:cursor-not-allowed disabled:transform-none" aria-label={`${t('increase')} ${label}`}> + </button>
        </div>
    </div>
);

const ToggleSwitch: React.FC<{ id: string; checked: boolean; onChange: () => void; label: string; tooltip?: string; }> = ({ id, checked, onChange, label, tooltip }) => (
    <div className="flex items-center justify-center w-full bg-gray-700 p-3 rounded-lg">
        <div className="tooltip" style={{ display: 'inline-block' }}>
            <label htmlFor={id} className="flex items-center cursor-pointer">
                <div className="relative">
                    <input type="checkbox" id={id} className="sr-only" checked={checked} onChange={onChange} />
                    <div className="block bg-gray-600 w-14 h-8 rounded-full"></div>
                    <div className={`dot absolute left-1 top-1 bg-white w-6 h-6 rounded-full transition ${checked ? 'transform translate-x-full bg-green-400' : ''}`}></div>
                </div>
                <div className="ml-3 text-gray-200 font-medium">{label}</div>
            </label>
            {tooltip && <div className="tooltiptext" style={{width: '260px', marginLeft: '-130px'}}>{tooltip}</div>}
        </div>
    </div>
);

const LevelUp: React.FC<LevelUpProps> = (props) => {
    const { player, playerData, basePlayerStats, points, gains, onAttributeIncrease, onAttributeDecrease, onContinue, autoDistributeEnabled, onToggleAutoDistribute, isRetrying, t, gameMode } = props;
    
    const title = isRetrying ? t('secondChanceTitle') : t('levelUpTitle');
    const titleColor = isRetrying ? "text-yellow-400" : "text-green-400";
    
    const continueButtonText = () => {
        if(isRetrying) return t('tryAgain');
        if(gameMode === 'story') return t('returnToMap');
        return t('nextChallenge');
    }
    
    return (
        <div className="animate-fade-in flex flex-col items-center gap-6 bg-gray-800 border-2 border-yellow-400 p-8 rounded-2xl max-w-2xl mx-auto shadow-lg">
            <h2 className={`text-4xl font-bold ${titleColor}`}>{title}</h2>

            {!isRetrying && (
              <div className="flex justify-around w-full text-center bg-gray-900/50 p-4 rounded-lg">
                  <p className="text-xl">{t('xpGained')}: <span className="font-bold text-blue-400">+{gains.xp}</span></p>
                  <p className="text-xl">{t('goldGained')}: <span className="font-bold text-yellow-400">+{gains.gold}</span></p>
                  {gains.interest > 0 && <p className="text-xl">{t('interest')}: <span className="font-bold text-yellow-400">+{gains.interest}</span></p>}
              </div>
            )}

            <div className="flex flex-col gap-4 w-full">
                <p className="text-xl text-center">{isRetrying ? t('secondChanceMessage') : t('levelUpMessage')} <span className="font-bold text-yellow-300 text-2xl">{points}</span> {t('points')}</p>
                <div className="w-full grid grid-cols-1 md:grid-cols-2 gap-3">
                    <AttributeControl t={t} label={t('statVitality')} value={player.vitality} icon="❤️‍🔥" onIncrease={() => onAttributeIncrease('vitality')} onDecrease={() => onAttributeDecrease('vitality')} increaseDisabled={points === 0} decreaseDisabled={playerData.vitality <= basePlayerStats.vitality} />
                    <AttributeControl t={t} label={t('statLuck')} value={player.luck} icon="🍀" onIncrease={() => onAttributeIncrease('luck')} onDecrease={() => onAttributeDecrease('luck')} increaseDisabled={points === 0} decreaseDisabled={playerData.luck <= basePlayerStats.luck} />
                    
                    {player.baseMagicAttack === 0 || player.attackType === 'physical' ? (
                        <AttributeControl t={t} label={t('statAttack')} value={player.attack} icon="⚔️" onIncrease={() => onAttributeIncrease('attack')} onDecrease={() => onAttributeDecrease('attack')} increaseDisabled={points === 0} decreaseDisabled={playerData.attack <= basePlayerStats.attack} />
                    ) : null}
                    {player.baseMagicAttack > 0 ? (
                        <AttributeControl t={t} label={t('statMagicAttack')} value={player.magicAttack} icon="✨" onIncrease={() => onAttributeIncrease('magicAttack')} onDecrease={() => onAttributeDecrease('magicAttack')} increaseDisabled={points === 0} decreaseDisabled={playerData.magicAttack <= basePlayerStats.magicAttack} />
                    ) : null}

                    <AttributeControl t={t} label={t('statDefense')} value={player.defense} icon="🛡️" onIncrease={() => onAttributeIncrease('defense')} onDecrease={() => onAttributeDecrease('defense')} increaseDisabled={points === 0} decreaseDisabled={playerData.defense <= basePlayerStats.defense} />
                    <AttributeControl t={t} label={t('statMagicDefense')} value={player.magicDefense} icon="🔮" onIncrease={() => onAttributeIncrease('magicDefense')} onDecrease={() => onAttributeDecrease('magicDefense')} increaseDisabled={points === 0} decreaseDisabled={playerData.magicDefense <= basePlayerStats.magicDefense} />
                    <AttributeControl t={t} label={t('statSpeed')} value={player.speed} icon="💨" onIncrease={() => onAttributeIncrease('speed')} onDecrease={() => onAttributeDecrease('speed')} increaseDisabled={points === 0} decreaseDisabled={playerData.speed <= basePlayerStats.speed} />
                    <AttributeControl t={t} label={t('statPrecision')} value={player.precision} icon="👁️" onIncrease={() => onAttributeIncrease('precision')} onDecrease={() => onAttributeDecrease('precision')} increaseDisabled={points === 0} decreaseDisabled={playerData.precision <= basePlayerStats.precision} />
                </div>
                 {points === 0 && (
                   <div className="flex flex-col items-center justify-center h-full text-center bg-gray-700/50 rounded-lg p-4 mt-2">
                        <p className="text-2xl font-bold">{t('almostThere')}</p>
                        <p className="text-gray-300">{t('almostThereMessage')}</p>
                   </div>
                )}
            </div>

            <div className="w-full flex flex-col items-center gap-4 mt-4">
                {(gameMode === 'survival' || gameMode === 'mastery') && !isRetrying && (
                    <ToggleSwitch id="auto-distribute-toggle" checked={autoDistributeEnabled} onChange={onToggleAutoDistribute} label={t('autoDistribute')} />
                )}
                <button onClick={onContinue} disabled={points > 0} className="w-full px-10 py-4 bg-blue-500 text-white font-bold rounded-lg border-2 border-blue-300 text-2xl hover:bg-blue-600 transition-all transform hover:scale-105 shadow-lg disabled:bg-gray-600 disabled:cursor-not-allowed disabled:transform-none">
                    {continueButtonText()}
                </button>
            </div>
        </div>
    );
};

export default LevelUp;
