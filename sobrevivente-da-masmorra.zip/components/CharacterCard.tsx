
import React from 'react';
import { Character, StatKey, DeterminationStatKey } from '../types';

interface CharacterCardProps {
  character: Character;
  isAttacking?: boolean;
  isPlayer?: boolean;
  determination?: { stat: DeterminationStatKey, boost: number } | null;
  determinationActive?: boolean;
  t: (key: any, params?: Record<string, string | number>) => string;
  opponentAttackType?: 'physical' | 'magical';
  opponent?: Character | null;
}

const Bar: React.FC<{ value: number; maxValue: number; colorClass: string; label: string }> = ({ value, maxValue, colorClass, label }) => {
  const percentage = maxValue > 0 ? (value / maxValue) * 100 : 0;
  return (
    <div className="w-full bg-gray-700 rounded-full h-6 border-2 border-gray-500 overflow-hidden relative">
      <div
        className={`${colorClass} h-full rounded-full transition-all duration-500 ease-in-out`}
        style={{ width: `${percentage}%` }}
      ></div>
      <div className="absolute inset-0 flex items-center justify-center">
         <span className="font-bold text-sm text-white" style={{textShadow: '1px 1px 2px black'}}>{label}</span>
      </div>
    </div>
  );
};

const Stat: React.FC<{ label: string; value: number | string; icon: string; isBoosted?: boolean; isDeemphasized?: boolean; }> = ({ label, value, icon, isBoosted, isDeemphasized }) => (
  <div className={`flex items-center space-x-3 bg-gray-700/50 p-2 rounded-lg h-full transition-opacity duration-300 ${isDeemphasized ? 'opacity-50' : ''}`}>
    <span className="text-2xl">{icon}</span>
    <div className="flex-grow">
      <span className="text-sm font-bold text-gray-300">{label}</span>
      <p className={`text-lg font-semibold ${isBoosted ? 'text-green-400 font-black animate-pulse' : 'text-white'}`}>{value}</p>
    </div>
  </div>
);

const StatWithTooltip: React.FC<{ label: string; value: number | string; icon: string; tooltipText: string; isBoosted?: boolean; isDeemphasized?: boolean; }> = ({ label, value, icon, tooltipText, isBoosted, isDeemphasized }) => (
    <div className="tooltip">
        <Stat label={label} value={value} icon={icon} isBoosted={isBoosted} isDeemphasized={isDeemphasized} />
        <div className="tooltiptext" style={{width: '280px', marginLeft: '-140px'}} dangerouslySetInnerHTML={{ __html: tooltipText }} />
    </div>
);

const CompactStatDisplay: React.FC<{ character: Character, t: (key: any) => string, opponent?: Character | null }> = ({ character, t, opponent }) => {
    const { precision, critChance, critMultiplier, absorptionChance, absorptionReduction } = character;
    
    const opponentSpeed = opponent?.speed ?? 0;
    const hitChance = Math.max(25, Math.min(100, 100 + (precision - opponentSpeed)));

    const items = [
        {
            icon: '👁️',
            label: t('statPrecision'),
            value: `${hitChance.toFixed(0)}%`,
            tooltip: `<strong>Chance de Acerto: ${hitChance.toFixed(0)}%</strong><hr class='my-1 border-gray-500'>Baseado na sua Precisão (${precision.toFixed(0)}) vs. Velocidade do Oponente (${opponentSpeed.toFixed(0)}).`
        },
        {
            icon: '🎯',
            label: t('statCrit'),
            value: `${(critChance * 100).toFixed(2)}%`,
            tooltip: `<strong>${t('statCrit')}: ${(critChance * 100).toFixed(2)}%</strong><hr class='my-1 border-gray-500'>Chance de causar <strong>${((1 + critMultiplier) * 100).toFixed(0)}%</strong> de dano.`
        },
        {
            icon: '🌀',
            label: t('statAbsorb'),
            value: `${(absorptionChance * 100).toFixed(2)}%`,
            tooltip: `<strong>${t('statAbsorb')}: ${(absorptionChance * 100).toFixed(2)}%</strong><hr class='my-1 border-gray-500'>Chance de absorver um ataque, reduzindo o dano em <strong>${(absorptionReduction * 100).toFixed(0)}%</strong>.`
        }
    ];

    return (
        <div className="flex items-center justify-center gap-2 mb-3">
            {items.map(item => (
                <div key={item.label} className="tooltip">
                    <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-gray-900/60 ring-1 ring-gray-600">
                        <span className="text-sm">{item.icon}</span>
                        <span className="text-xs font-bold text-white">{item.value}</span>
                    </div>
                    <div className="tooltiptext !w-60 !-ml-32" dangerouslySetInnerHTML={{ __html: item.tooltip }} />
                </div>
            ))}
        </div>
    );
};


const CharacterCard: React.FC<CharacterCardProps> = ({ character, isAttacking, isPlayer = false, determination, determinationActive, t, opponentAttackType, opponent }) => {
  const { name, hp, maxHp, attack, defense, speed, avatar, xp, xpToNextLevel, level, lives, magicAttack, magicDefense, attackType, vitality, luck, precision } = character;
  const cardClasses = `relative bg-gray-800 p-6 rounded-2xl shadow-lg border-2 border-gray-700 flex flex-col gap-4 transition-transform duration-300 w-full max-w-sm ${isAttacking ? 'animate-shake' : ''}`;
  
  const hpPercentage = maxHp > 0 ? (hp / maxHp) * 100 : 0;
  let hpBarColor = 'bg-green-500';
  if (hpPercentage < 50) hpBarColor = 'bg-yellow-500';
  if (hpPercentage < 25) hpBarColor = 'bg-red-500';

  const determinationBoostedStat = isPlayer ? determination?.stat : null;
  const boostValue = isPlayer ? determination?.boost || 0 : 0;

  const displayAttack = attack + (determinationBoostedStat === 'attack' ? boostValue : 0);
  const displayMagicAttack = magicAttack + (determinationBoostedStat === 'magicAttack' ? boostValue : 0);
  const displayDefense = defense + (determinationBoostedStat === 'defense' ? boostValue : 0);
  const displayMagicDefense = magicDefense + (determinationBoostedStat === 'magicDefense' ? boostValue : 0);
  const displaySpeed = speed + (determinationBoostedStat === 'speed' ? boostValue : 0);
  const displayVitality = vitality + (determinationBoostedStat === 'vitality' ? boostValue : 0);
  const displayLuck = luck + (determinationBoostedStat === 'luck' ? boostValue : 0);
  const displayPrecision = precision + (determinationBoostedStat === 'precision' ? boostValue : 0);

  const tooltips = {
    attack: `<strong>Dano Físico:</strong> ${displayAttack.toFixed(0)}<hr class='my-1 border-gray-500'>Calculado contra a Defesa Física do inimigo.`,
    magicAttack: `<strong>Dano Mágico:</strong> ${displayMagicAttack.toFixed(0)}<hr class='my-1 border-gray-500'>Calculado contra a Defesa Mágica do inimigo.`,
    defense: `<strong>Defesa Física:</strong> ${displayDefense.toFixed(0)}<hr class='my-1 border-gray-500'>Reduz o dano de ataques físicos.`,
    magicDefense: `<strong>Defesa Mágica:</strong> ${displayMagicDefense.toFixed(0)}<hr class='my-1 border-gray-500'>Reduz o dano de ataques mágicos.`,
    speed: `<strong>Velocidade:</strong> ${displaySpeed.toFixed(0)}<hr class='my-1 border-gray-500'>Determina a frequência dos ataques.`,
    luck: `<strong>Sorte:</strong> ${displayLuck.toFixed(0)}<hr class='my-1 border-gray-500'>Aumenta chances de Crítico, Absorção e Ouro ganho.`
  };
  
  const statNameMap: { [key: string]: string } = { attack: t('statAttack'), defense: t('statDefense'), speed: t('statSpeed'), critChance: t('statCrit'), maxHp: t('statLife'), magicAttack: t('statMagicAttack'), magicDefense: t('statMagicDefense'), precision: t('statPrecision'), vitality: t('statVitality'), luck: t('statLuck') };
  const determinationTooltip = determination
    ? `Determinação Ativa!<hr class='my-1 border-gray-500'><strong>Bônus:</strong> +${determination.boost.toFixed(2)}${determination.stat === 'critChance' ? '%' : ''} de ${statNameMap[determination.stat]}`
    : '';

  return (
    <div className={cardClasses}>
      <CompactStatDisplay character={character} t={t} opponent={opponent} />
      {isPlayer && determinationActive && (
          <div className="tooltip absolute -top-3 -right-3 text-5xl animate-pulse">
             <span>🔥</span>
             <div className="tooltiptext" style={{width: '240px', marginLeft: '-120px'}} dangerouslySetInnerHTML={{ __html: determinationTooltip }} />
          </div>
      )}
      <div className="flex items-center gap-4">
        <div className="w-20 h-20 flex-shrink-0 bg-gray-900/50 rounded-lg flex items-center justify-center">
            <span className="text-7xl" style={{fontFamily: "'Noto Color Emoji', sans-serif"}}>{avatar}</span>
        </div>
        <div className="flex-grow">
          <h2 className="text-4xl font-bold text-yellow-300">{name}</h2>
          <div className='flex items-baseline gap-4'>
            {level && <p className="text-lg text-blue-300 font-semibold">{t('level')} {level}</p>}
             {isPlayer && typeof lives === 'number' && (
                <p className="text-lg text-red-400 font-semibold flex items-center gap-1">
                    {t('lives')}: {lives} <span className='text-xl'>❤️</span>
                </p>
             )}
          </div>
        </div>
      </div>
      <div className="space-y-2">
        <Bar value={hp} maxValue={maxHp} colorClass={hpBarColor} label={`${Math.round(hp)} / ${Math.round(maxHp)}`} />
        {isPlayer && xpToNextLevel > 0 && <Bar value={xp} maxValue={xpToNextLevel} colorClass="bg-blue-500" label={`XP: ${xp} / ${xpToNextLevel}`} />}
      </div>
      <div className="grid grid-cols-2 gap-3 mt-2">
        {opponentAttackType ? (
          // In-battle 2x2 layout
          <>
            {attackType === 'physical'
              ? <StatWithTooltip label={t('statAttack')} value={displayAttack.toFixed(0)} icon="⚔️" tooltipText={tooltips.attack} isBoosted={determinationBoostedStat === 'attack'} />
              : <StatWithTooltip label={t('statMagicAttack')} value={displayMagicAttack.toFixed(0)} icon="✨" tooltipText={tooltips.magicAttack} isBoosted={determinationBoostedStat === 'magicAttack'} />}
            
            {opponentAttackType === 'physical'
              ? <StatWithTooltip label={t('statDefense')} value={displayDefense.toFixed(0)} icon="🛡️" tooltipText={tooltips.defense} isBoosted={determinationBoostedStat === 'defense'} />
              : <StatWithTooltip label={t('statMagicDefense')} value={displayMagicDefense.toFixed(0)} icon="🔮" tooltipText={tooltips.magicDefense} isBoosted={determinationBoostedStat === 'magicDefense'} />}

            <StatWithTooltip label={t('statSpeed')} value={displaySpeed.toFixed(0)} icon="💨" tooltipText={tooltips.speed} isBoosted={determinationBoostedStat === 'speed'} />
            <StatWithTooltip label={t('statLuck')} value={displayLuck.toFixed(0)} icon="🍀" tooltipText={tooltips.luck} isBoosted={determinationBoostedStat === 'luck'} />
          </>
        ) : (
          // Original layout for out-of-battle
          <>
            <StatWithTooltip label={t('statLuck')} value={displayLuck.toFixed(0)} icon="🍀" tooltipText={tooltips.luck} isBoosted={determinationBoostedStat === 'luck'} />
            <StatWithTooltip label={t('statSpeed')} value={displaySpeed.toFixed(0)} icon="💨" tooltipText={tooltips.speed} isBoosted={determinationBoostedStat === 'speed'} />

            <div className="col-span-2">
                {attackType === 'physical' 
                ? <StatWithTooltip label={t('statAttack')} value={displayAttack.toFixed(0)} icon="⚔️" tooltipText={tooltips.attack} isBoosted={determinationBoostedStat === 'attack'} />
                : <StatWithTooltip label={t('statMagicAttack')} value={displayMagicAttack.toFixed(0)} icon="✨" tooltipText={tooltips.magicAttack} isBoosted={determinationBoostedStat === 'magicAttack'} />}
            </div>
            
            <StatWithTooltip label={t('statDefense')} value={displayDefense.toFixed(0)} icon="🛡️" tooltipText={tooltips.defense} isBoosted={determinationBoostedStat === 'defense'} />
            <StatWithTooltip label={t('statMagicDefense')} value={displayMagicDefense.toFixed(0)} icon="🔮" tooltipText={tooltips.magicDefense} isBoosted={determinationBoostedStat === 'magicDefense'} />
          </>
        )}
      </div>
    </div>
  );
};

export default CharacterCard;