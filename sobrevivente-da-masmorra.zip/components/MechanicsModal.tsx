
import React from 'react';

interface MechanicsModalProps {
    onClose: () => void;
    t: (key: any, params?: Record<string, string | number>) => string;
}

const Section: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
    <div className="bg-gray-700/50 p-4 rounded-lg">
        <h3 className="text-xl font-bold text-yellow-300 mb-2">{title}</h3>
        <div className="text-gray-300 space-y-2 text-sm" dangerouslySetInnerHTML={{ __html: children as string }} />
    </div>
);

const MechanicsModal: React.FC<MechanicsModalProps> = ({ onClose, t }) => {
    return (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 animate-modal-fade-in">
            <div className="bg-gray-800 rounded-2xl border-2 border-yellow-400 p-8 shadow-lg max-w-2xl w-full flex flex-col gap-6">
                <h2 className="text-3xl font-bold text-center mb-2 text-yellow-300">{t('mechanicsTitle')}</h2>
                
                <div className="w-full max-h-[60vh] overflow-y-auto space-y-4 pr-2">
                    <Section title={t('mechanicsVitalityTitle')}>{t('mechanicsVitalityDesc')}</Section>
                    <Section title={t('mechanicsAttackTitle')}>{t('mechanicsAttackDesc')}</Section>
                    <Section title={t('mechanicsMagicAttackTitle')}>{t('mechanicsMagicAttackDesc')}</Section>
                    <Section title={t('mechanicsDefenseTitle')}>{t('mechanicsDefenseDesc')}</Section>
                    <Section title={t('mechanicsMagicDefenseTitle')}>{t('mechanicsMagicDefenseDesc')}</Section>
                    <Section title={t('mechanicsSpeedTitle')}>{t('mechanicsSpeedDesc')}</Section>
                    <Section title={t('mechanicsLuckTitle')}>{t('mechanicsLuckDesc')}</Section>
                    <Section title={t('mechanicsHitChanceTitle')}>{t('mechanicsHitChanceDesc')}</Section>
                    <Section title={t('mechanicsDamageTitle')}>{t('mechanicsDamageDesc')}</Section>
                    <Section title={t('mechanicsCritTitle')}>{t('mechanicsCritDesc')}</Section>
                    <Section title={t('mechanicsAbsorbTitle')}>{t('mechanicsAbsorbDesc')}</Section>
                    <Section title={t('mechanicsDeterminationTitle')}>{t('mechanicsDeterminationDesc')}</Section>
                    <Section title={t('mechanicsLevelScalingTitle')}>{t('mechanicsLevelScalingDesc')}</Section>
                </div>

                <button onClick={onClose} className="w-full px-10 py-3 bg-blue-600 text-white font-bold rounded-lg border-2 border-blue-400 text-xl hover:bg-blue-700 transition-all">
                    {t('mechanicsClose')}
                </button>
            </div>
        </div>
    );
};

export default MechanicsModal;
