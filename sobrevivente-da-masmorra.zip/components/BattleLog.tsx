import React, { useEffect, useRef } from 'react';

interface BattleLogProps {
  log: string[];
  t: (key: any, params?: Record<string, string | number>) => string;
}

const BattleLog: React.FC<BattleLogProps> = ({ log, t }) => {
  const logEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (logEndRef.current) {
        logEndRef.current.scrollTop = logEndRef.current.scrollHeight;
    }
  }, [log]);

  if (log.length === 0) return null;

  const getEntryStyle = (entry: string): string => {
    if (entry.includes(t('winner').split(' ')[0]) || entry.includes('Vitória')) {
      return 'text-green-400 font-bold';
    }
    if (entry.includes(t('criticalHit').split('!')[0])) {
      return 'text-yellow-400 font-semibold animate-pulse';
    }
     if (entry.includes(t('missedHit').split(' ')[1])) {
      return 'text-sky-400';
    }
    return 'text-gray-300';
  };

  return (
    <div ref={logEndRef} className="w-full h-48 bg-gray-900/50 border-2 border-gray-700 rounded-lg p-4 mt-4 overflow-y-auto">
      <div className="flex flex-col space-y-2 text-sm font-mono">
        {log.map((entry, index) => (
          <p key={index} className="animate-fade-in">
            <span className="text-gray-500 mr-2">{t('battleLogEntry', {index})}</span>
            <span className={getEntryStyle(entry)}>{entry}</span>
          </p>
        ))}
      </div>
    </div>
  );
};

export default BattleLog;