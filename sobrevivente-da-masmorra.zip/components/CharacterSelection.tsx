
import React from 'react';
import { Character } from '../types';

interface CharacterSelectionProps {
  heroes: Character[];
  onSelect: (character: Character) => void;
  onBack: () => void;
  t: (key: any) => string;
}

const Stat: React.FC<{ label: string; value: number | string; icon: string }> = ({ label, value, icon }) => (
  <li className="flex items-center space-x-2">
    <span className="text-xl">{icon}</span>
    <div className="flex-grow">
      <span className="text-xs font-bold text-gray-400">{label}</span>
      <p className="text-md font-semibold text-white">{value}</p>
    </div>
  </li>
);

const CharacterSelectionCard: React.FC<{ 
    character: Character; 
    onSelect: () => void;
    t: (key: any) => string; 
}> = ({ character, onSelect, t }) => {
  const { name, avatar, attack, defense, speed, magicAttack, magicDefense, attackType, precision, vitality, luck } = character;
  
  return (
    <div 
      className="bg-gray-800 p-4 rounded-2xl shadow-lg border-2 border-gray-700 flex flex-col gap-3 text-center cursor-pointer transform transition-all hover:scale-105 hover:border-yellow-400 duration-300"
      onClick={onSelect}
      role="button"
      tabIndex={0}
      onKeyPress={(e) => (e.key === 'Enter' || e.key === ' ') && onSelect()}
      aria-label={`${t('selectHero')} ${name}`}
    >
      <div className="w-32 h-32 self-center mb-2 bg-gray-900/50 rounded-lg flex items-center justify-center">
        <span className="text-8xl self-center">{avatar}</span>
      </div>
      <h3 className="text-3xl font-bold text-yellow-300">{name}</h3>
      <ul className="grid grid-cols-2 gap-x-4 gap-y-2 mt-2 text-left">
        <Stat label={t('statVitality')} value={vitality} icon="❤️‍🔥" />
        <Stat label={t('statLuck')} value={luck} icon="🍀" />
        {attackType === 'physical' 
          ? <Stat label={t('statAttack')} value={attack} icon="⚔️" />
          : <Stat label={t('statMagicAttack')} value={magicAttack} icon="✨" />
        }
        <Stat label={t('statDefense')} value={defense} icon="🛡️" />
        <Stat label={t('statSpeed')} value={speed} icon="💨" />
        <Stat label={t('statMagicDefense')} value={magicDefense} icon="🔮" />
        <Stat label={t('statPrecision')} value={precision} icon="👁️" />
      </ul>
    </div>
  );
};

const CharacterSelection: React.FC<CharacterSelectionProps> = ({ heroes, onSelect, onBack, t }) => {
  return (
    <div className="animate-fade-in">
      <h2 className="text-4xl font-bold text-center mb-8">{t('heroSelectionTitle')}</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-screen-lg mx-auto">
        {heroes.map(hero => (
          <CharacterSelectionCard 
            key={hero.id} 
            character={hero} 
            onSelect={() => onSelect(hero)} 
            t={t} 
          />
        ))}
      </div>
      <div className="text-center mt-10">
        <button onClick={onBack} className="px-8 py-3 bg-gray-600 text-white font-bold rounded-lg text-xl hover:bg-gray-500 transition-all">
          {t('back')}
        </button>
      </div>
    </div>
  );
};

export default CharacterSelection;