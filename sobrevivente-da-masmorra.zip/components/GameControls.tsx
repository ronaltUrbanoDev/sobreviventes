import React from 'react';
import { GameState, GameMode } from '../types';

interface GameControlsProps {
  gameState: GameState;
  winner: string | null;
  playerWon: boolean;
  playerLives: number;
  onStart: () => void;
  onGoHome: () => void;
  onContinueAfterDefeat: () => void;
  t: (key: any, params?: Record<string, string | number>) => string;
  gameMode: GameMode;
}

const GameControls: React.FC<GameControlsProps> = ({ gameState, winner, playerWon, playerLives, onStart, onGoHome, onContinueAfterDefeat, t, gameMode }) => {
  const renderDefeatScreen = () => {
    if (playerLives > 0 && gameMode === 'survival') {
      return (
        <div className="flex flex-col items-center gap-2 animate-fade-in">
          <h2 className="text-4xl font-bold text-red-500">{t('youWereDefeated')}</h2>
          <p className="text-lg text-gray-300">{t('useLifeToRetry')}</p>
          <p className="text-sm text-yellow-400 font-semibold">{t('retryBonus')}</p>
          <div className="flex gap-4 mt-2">
            <button
              onClick={onContinueAfterDefeat}
              className="px-8 py-3 bg-green-500 text-white font-bold rounded-lg border-2 border-green-300 text-xl hover:bg-green-600 transition-all transform hover:scale-105 shadow-lg"
            >
              {t('continue')} ({t('lives')}: {playerLives})
            </button>
            <button
              onClick={onGoHome}
              className="px-8 py-3 bg-gray-700 text-white font-bold rounded-lg border-2 border-gray-500 text-xl hover:bg-gray-600 transition-all transform hover:scale-105 shadow-lg"
            >
              {t('giveUp')}
            </button>
          </div>
        </div>
      );
    }
    return (
      <div className="flex flex-col items-center gap-4 animate-fade-in">
        <h2 className="text-4xl font-bold text-red-500">{t('gameOver')}</h2>
        <button
          onClick={onGoHome}
          className="px-8 py-3 bg-yellow-500 text-black font-bold rounded-lg border-2 border-yellow-300 text-xl hover:bg-yellow-600 transition-all transform hover:scale-105 shadow-lg"
        >
          {t('tryAgain')}
        </button>
      </div>
    );
  };

  return (
    <div className="text-center py-4 h-36 flex flex-col items-center justify-center">
      {gameState === 'ready' && (
        <button
          onClick={onStart}
          className="px-10 py-4 bg-green-500 text-white font-bold rounded-lg border-2 border-green-300 text-2xl hover:bg-green-600 transition-all transform hover:scale-105 shadow-lg"
        >
          {t('startBattle')}
        </button>
      )}
      {gameState === 'battling' && !winner && (
        <div className="text-2xl text-yellow-400 font-bold animate-pulse">
          {t('battling')}
        </div>
      )}
      {gameState === 'over' && !playerWon && renderDefeatScreen()}
    </div>
  );
};

export default GameControls;