import React, { useState } from 'react';
import { Character, EquipmentItem, EquipmentSlot, StatKey } from '../types';
import { RARITY_COLORS, RARITY_BORDER_COLORS, getStatTranslationKey } from '../constants';

interface ShopModalProps {
    player: Character;
    items: EquipmentItem[];
    onPurchase: (item: EquipmentItem) => void;
    onSell: (item: EquipmentItem) => void;
    onEquip: (item: EquipmentItem) => void;
    onUnequip: (item: EquipmentItem) => void;
    onClose: () => void;
    t: (key: any, params?: Record<string, string | number>) => string;
}

const ItemCard: React.FC<{ item: EquipmentItem, t: ShopModalProps['t'], children: React.ReactNode }> = ({ item, t, children }) => (
    <div className={`flex flex-col gap-2 bg-gray-700/80 p-3 rounded-lg border-2 ${RARITY_BORDER_COLORS[item.rarity]}`}>
       <div className="flex items-start gap-3">
           <span className="text-4xl mt-1">{item.icon}</span>
           <div className="flex-grow">
               <p className={`font-semibold text-lg ${RARITY_COLORS[item.rarity]}`}>{item.name}</p>
               <div className="text-xs text-gray-300 space-y-0.5">
                   {Object.entries(item.stats).map(([stat, value]) => (
                       <p key={stat}>+{value} {t(getStatTranslationKey(stat as StatKey))}</p>
                   ))}
               </div>
           </div>
       </div>
       <div className="mt-auto">
        {children}
       </div>
   </div>
);


const EquipmentView: React.FC<{ player: Character; onEquip: (item: EquipmentItem) => void; onUnequip: (item: EquipmentItem) => void; t: ShopModalProps['t'] }> = ({ player, onEquip, onUnequip, t }) => {
    const [selectedSlot, setSelectedSlot] = useState<EquipmentSlot | null>(null);
    const slots: EquipmentSlot[] = ['weapon', 'shield', 'helmet', 'armor', 'boots', 'necklace'];
    const slotIcons: Record<EquipmentSlot, string> = { weapon: '⚔️', shield: '🛡️', helmet: '⛑️', armor: '🎽', boots: '👢', necklace: '💍' };

    const getTooltipStyle = (): React.CSSProperties => ({
        position: 'absolute', top: '100%', bottom: 'auto', marginTop: '10px',
        zIndex: 100, left: '50%', transform: 'translateX(-50%)'
    });

    if (selectedSlot) {
        const itemsForSlot = player.inventory.filter(i => i.slot === selectedSlot);
        const equippedItem = player.equipment[selectedSlot];

        return (
            <div className='flex flex-col gap-4 animate-fade-in'>
                <div className='flex items-center gap-4 border-b border-gray-600 pb-3'>
                    <button onClick={() => setSelectedSlot(null)} className='px-4 py-2 bg-gray-600 text-white font-bold rounded-lg hover:bg-gray-500 transition-colors'>{t('back')}</button>
                    <h3 className='text-2xl font-bold text-yellow-300'>{t('selectItem')} - {t(selectedSlot)}</h3>
                </div>
                <div className='grid grid-cols-1 md:grid-cols-2 gap-3 max-h-[45vh] overflow-y-auto p-2 bg-gray-900/50 rounded-lg'>
                    {equippedItem && (
                         <div>
                            <ItemCard item={equippedItem} t={t}>
                               <button onClick={() => { onUnequip(equippedItem); setSelectedSlot(null); }} className="w-full mt-2 px-4 py-2 bg-red-600 text-white font-bold rounded-lg text-sm hover:bg-red-500 transition-all text-center">
                                    Desequipar
                               </button>
                            </ItemCard>
                        </div>
                    )}
                    {itemsForSlot.map(item => (
                        <button onClick={() => { onEquip(item); setSelectedSlot(null); }} key={item.id} className="text-left">
                           <ItemCard item={item} t={t}>
                               <div className="w-full mt-2 px-4 py-2 bg-blue-600 text-white font-bold rounded-lg text-sm hover:bg-blue-500 transition-all text-center">
                                    Equipar
                               </div>
                           </ItemCard>
                        </button>
                    ))}
                    {itemsForSlot.length === 0 && !equippedItem && (
                        <p className="text-gray-400 text-center col-span-full py-8">Nenhum item para este espaço no inventário.</p>
                    )}
                </div>
            </div>
        );
    }
    
    return (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3 animate-fade-in">
            {slots.map((slot) => {
                const item = player.equipment[slot];
                return (
                    <button key={slot} onClick={() => setSelectedSlot(slot)} className="flex flex-col items-center justify-center bg-gray-700/80 p-3 rounded-lg h-32 hover:bg-gray-700 transition-colors">
                        <div className="tooltip">
                            <div className={`w-16 h-16 bg-gray-900/50 rounded-lg flex items-center justify-center text-3xl border-2 ${item ? RARITY_BORDER_COLORS[item.rarity] : 'border-gray-600'}`}>
                                {item ? item.icon : <span className="filter grayscale opacity-50 text-3xl">{slotIcons[slot]}</span>}
                            </div>
                            {item && (
                                <div className="tooltiptext !w-60" style={getTooltipStyle()}>
                                    <p className={`font-bold text-lg ${RARITY_COLORS[item.rarity]}`}>{item.name}</p>
                                    <div className="text-left text-sm mt-2 space-y-1">
                                        {Object.entries(item.stats).map(([stat, value]) => (
                                            <p key={stat}>+{value} {t(getStatTranslationKey(stat as StatKey))}</p>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </div>
                        <p className="mt-2 font-semibold text-gray-300 text-sm">{t(slot)}</p>
                    </button>
                );
            })}
        </div>
    );
};


const ShopModal: React.FC<ShopModalProps> = ({ player, items, onPurchase, onSell, onEquip, onUnequip, onClose, t }) => {
    const [activeTab, setActiveTab] = useState('buy');

    return (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-40 animate-modal-fade-in">
            <div className="bg-gray-800 rounded-2xl border-2 border-yellow-400 p-6 shadow-lg max-w-4xl w-full flex flex-col gap-4">
                <div className="flex justify-between items-center">
                    <h2 className="text-4xl font-bold text-yellow-300">{t('shopTitle')}</h2>
                    <p className="text-2xl font-bold text-yellow-400">💰 {player.gold}</p>
                </div>
                
                <div className="flex justify-center border-b-2 border-gray-600">
                    <button onClick={() => setActiveTab('buy')} className={`px-6 py-2 text-xl font-bold transition-colors ${activeTab === 'buy' ? 'text-yellow-300 border-b-2 border-yellow-300' : 'text-gray-400 hover:text-yellow-200'}`}>{t('buy')}</button>
                    <button onClick={() => setActiveTab('sell')} className={`px-6 py-2 text-xl font-bold transition-colors ${activeTab === 'sell' ? 'text-yellow-300 border-b-2 border-yellow-300' : 'text-gray-400 hover:text-yellow-200'}`}>{t('sell')}</button>
                    <button onClick={() => setActiveTab('equipment')} className={`px-6 py-2 text-xl font-bold transition-colors ${activeTab === 'equipment' ? 'text-yellow-300 border-b-2 border-yellow-300' : 'text-gray-400 hover:text-yellow-200'}`}>{t('equipment')}</button>
                </div>

                <div className="w-full min-h-[60vh] bg-gray-900/50 p-4 rounded-lg overflow-y-auto">
                    {activeTab === 'buy' && (
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 animate-fade-in">
                            {items.length > 0 ? items.map(item => (
                                 <ItemCard key={item.id} item={item} t={t}>
                                    <button onClick={() => onPurchase(item)} disabled={player.gold < item.cost} className="w-full mt-2 px-4 py-2 bg-yellow-600 text-white font-bold rounded-lg text-sm hover:bg-yellow-500 transition-all disabled:bg-gray-600 disabled:cursor-not-allowed">
                                        {t('buy')} 💰 {item.cost}
                                    </button>
                                 </ItemCard>
                            )) : <p className="text-center text-gray-400 md:col-span-3 py-8">Sem itens novos no momento.</p>}
                        </div>
                    )}
                    {activeTab === 'sell' && (
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 animate-fade-in">
                           {(() => {
                                const inventoryItems = player.inventory;
                                const equippedItems = Object.values(player.equipment).filter(Boolean) as EquipmentItem[];
                                
                                const allItems = [...inventoryItems, ...equippedItems];
                                const equippedItemIds = new Set(equippedItems.map(i => i.id));

                                const seenIds = new Set();
                                const uniqueDisplayItems = allItems.filter(item => {
                                    if (seenIds.has(item.id)) return false;
                                    seenIds.add(item.id);
                                    return true;
                                });

                                if (uniqueDisplayItems.length === 0) {
                                    return <p className="text-center text-gray-400 md:col-span-3 py-8">Nenhum item para vender ou equipado.</p>;
                                }

                                return uniqueDisplayItems.map(item => {
                                    const isEquipped = equippedItemIds.has(item.id);
                                    return (
                                        <ItemCard key={item.id} item={item} t={t}>
                                            {isEquipped ? (
                                                <div className="w-full mt-2 px-4 py-2 bg-gray-600 text-white font-bold rounded-lg text-sm text-center cursor-not-allowed">
                                                    Equipado
                                                </div>
                                            ) : (
                                                <button onClick={() => onSell(item)} className="w-full mt-2 px-4 py-2 bg-green-600 text-white font-bold rounded-lg text-sm hover:bg-green-500 transition-all">
                                                    {t('sell')} 💰 {Math.floor(item.cost * 0.4)}
                                                </button>
                                            )}
                                        </ItemCard>
                                    );
                                });
                            })()}
                        </div>
                    )}
                    {activeTab === 'equipment' && (
                       <EquipmentView player={player} onEquip={onEquip} onUnequip={onUnequip} t={t} />
                    )}
                </div>

                <button onClick={onClose} className="w-full mt-4 px-10 py-4 bg-red-600 text-white font-bold rounded-lg border-2 border-red-400 text-2xl hover:bg-red-700 transition-all">
                    {t('close')}
                </button>
            </div>
        </div>
    );
};

export default ShopModal;