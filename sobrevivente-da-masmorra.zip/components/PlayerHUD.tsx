
import React from 'react';
import { Character, Consumable } from '../types';

interface PlayerHUDProps {
    player: Character;
    onEquipmentClick: () => void;
    onGoHome: () => void;
    t: (key: any, params?: Record<string, string | number>) => string;
}

const Bar: React.FC<{ value: number; maxValue: number; colorClass: string; label?: string }> = ({ value, maxValue, colorClass, label }) => {
    const percentage = maxValue > 0 ? (value / maxValue) * 100 : 0;
    return (
      <div className="w-full bg-gray-700 rounded-full h-5 border border-gray-500 overflow-hidden relative">
        <div className={`${colorClass} h-full rounded-full transition-all duration-300 ease-in-out`} style={{ width: `${percentage}%` }}></div>
        {label && <div className="absolute inset-0 flex items-center justify-center"><span className="font-bold text-xs text-white" style={{textShadow: '1px 1px 1px black'}}>{label}</span></div>}
      </div>
    );
};

const PlayerHUD: React.FC<PlayerHUDProps> = ({ player, onEquipmentClick, onGoHome, t }) => {
    const effectiveStats = player;
    const hasNewItem = player.inventory.some(i => i.isNew) || Object.values(player.equipment).some(i => i?.isNew);
    return (
        <div className="fixed top-0 left-0 right-0 bg-gray-900/90 backdrop-blur-sm border-b-2 border-yellow-500 shadow-lg p-3 z-20 animate-fade-in">
            <div className="max-w-6xl mx-auto flex justify-between items-center gap-4">
                {/* Left Side: Vitals & XP */}
                <div className="flex-1 flex flex-col gap-2">
                    <div className="flex items-center gap-2">
                        <div className="w-10 h-10 flex-shrink-0 bg-gray-800 rounded-md flex items-center justify-center">
                           <span className="text-2xl">{player.avatar}</span>
                        </div>
                        <h3 className="text-xl font-bold text-white">{player.name} - {t('level')} {player.level}</h3>
                    </div>
                    <Bar value={player.hp} maxValue={player.maxHp} colorClass="bg-green-500" label={`${Math.round(player.hp)} / ${Math.round(player.maxHp)}`} />
                    <Bar value={player.xp} maxValue={player.xpToNextLevel} colorClass="bg-blue-500" label={`XP: ${player.xp} / ${player.xpToNextLevel}`} />
                </div>
                
                {/* Center: Gold and Equipment Button */}
                 <div className="flex items-center gap-4">
                    <div className="text-2xl font-bold text-yellow-400 flex items-center gap-2">
                        <span>💰</span>
                        <span>{player.gold}</span>
                    </div>
                    <button onClick={onEquipmentClick} className="relative flex items-center gap-2 px-4 py-2 bg-gray-700 rounded-lg border-2 border-gray-500 hover:bg-gray-600 transition-colors">
                       <span className="text-2xl">🎒</span>
                       <span className="font-bold text-yellow-300">{t('equipment')}</span>
                       {hasNewItem && <div className="absolute -top-1.5 -right-1.5 w-4 h-4 bg-red-500 rounded-full border-2 border-gray-900 animate-pulse"></div>}
                    </button>
                     <button onClick={onGoHome} className="flex items-center gap-2 px-4 py-2 bg-red-800 rounded-lg border-2 border-red-500 hover:bg-red-700 transition-colors">
                       <span className="text-xl">🚪</span>
                       <span className="font-bold text-white text-sm">{t('goHome')}</span>
                    </button>
                </div>

                {/* Right Side: Core Stats */}
                <div className="flex-1 flex items-center justify-end gap-6">
                    <div className="grid grid-cols-3 gap-x-4 gap-y-1 text-sm font-semibold">
                        <div className="flex items-center gap-1 text-white">⚔️ {effectiveStats.attack.toFixed(0)}</div>
                        <div className="flex items-center gap-1 text-white">🛡️ {effectiveStats.defense.toFixed(0)}</div>
                        <div className="flex items-center gap-1 text-white">💨 {effectiveStats.speed.toFixed(0)}</div>
                        <div className="flex items-center gap-1 text-white">✨ {effectiveStats.magicAttack.toFixed(0)}</div>
                        <div className="flex items-center gap-1 text-white">🔮 {effectiveStats.magicDefense.toFixed(0)}</div>
                        <div className="flex items-center gap-1 text-white">👁️ {effectiveStats.precision.toFixed(0)}</div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default PlayerHUD;