import React from 'react';

interface SplashScreenProps {
  onStart: () => void;
  onSettings: () => void;
  onMechanics: () => void;
  onSetLanguage: (lang: 'pt' | 'en') => void;
  t: (key: any) => string;
}

const SplashScreen: React.FC<SplashScreenProps> = ({ onStart, onSettings, onMechanics, onSetLanguage, t }) => {
  return (
    <div className="relative flex flex-col items-center justify-center text-center animate-fade-in pt-12 pb-12">
      <div className="absolute top-0 left-0 flex items-center gap-4">
        <div className="flex gap-2 bg-gray-800/70 p-2 rounded-lg">
            <button onClick={() => onSetLanguage('pt')} className="px-3 py-1 text-2xl rounded-md hover:bg-gray-700 transition-colors">🇧🇷</button>
            <button disabled className="px-3 py-1 text-2xl rounded-md hover:bg-gray-700 transition-colors opacity-50 cursor-not-allowed">🇺🇸</button>
        </div>
      </div>

      <div className="text-8xl mb-8 animate-pulse">⚔️</div>
      <h2 className="text-4xl md:text-5xl font-bold text-gray-100">
        {t('splashTitle')}
      </h2>
      <p className="text-lg md:text-xl text-gray-400 mt-4 mb-12 max-w-2xl">
        {t('splashSubtitle')}
      </p>
      
      <div className="flex flex-col items-center gap-4 w-full max-w-xs">
        <button
          onClick={onStart}
          className="w-full px-12 py-5 bg-green-500 text-white font-bold rounded-lg border-2 border-green-300 text-3xl hover:bg-green-600 transition-all transform hover:scale-105 shadow-lg"
        >
          {t('splashButton')}
        </button>
        <button 
          onClick={onSettings} 
          className="w-full px-8 py-3 bg-gray-700 text-white font-bold rounded-lg text-xl hover:bg-gray-600 transition-all transform hover:scale-105"
        >
          {t('settings')}
        </button>
        <button 
          onClick={onMechanics}
          className="w-full px-8 py-3 bg-gray-700 text-white font-bold rounded-lg text-xl hover:bg-gray-600 transition-all transform hover:scale-105"
        >
          {t('formulas')}
        </button>
      </div>
    </div>
  );
};

export default SplashScreen;