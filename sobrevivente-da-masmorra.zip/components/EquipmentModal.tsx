
import React, { useState, useMemo } from 'react';
import { Character, EquipmentItem, EquipmentSlot, PlayerStatKey, Consumable, StatKey } from '../types';
import { RARITY_COLORS, RARITY_BORDER_COLORS, getStatTranslationKey } from '../constants';

interface EquipmentModalProps {
    player: Character;
    onClose: () => void;
    onEquip: (item: EquipmentItem) => void;
    onUnequip: (item: EquipmentItem) => void;
    onUseConsumable: (item: Consumable) => void;
    t: (key: any, params?: any) => string;
}

const ItemCard: React.FC<{ item: EquipmentItem, t: EquipmentModalProps['t'], children: React.ReactNode, isEquipped?: boolean }> = ({ item, t, children, isEquipped }) => (
     <div className={`relative flex flex-col gap-2 bg-gray-700/80 p-3 rounded-lg border-2 h-full ${RARITY_BORDER_COLORS[item.rarity]}`}>
       {item.isNew && !isEquipped && <div className="absolute top-1 right-1 bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full shadow-md z-10 animate-pulse">NOVO</div>}
       {isEquipped && <div className="absolute top-1 right-1 bg-green-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full shadow-md z-10">E</div>}
       <div className="flex items-start gap-3">
           <span className="text-4xl mt-1">{item.icon}</span>
           <div className="flex-grow">
               <p className={`font-semibold text-lg ${RARITY_COLORS[item.rarity]}`}>{item.name}</p>
               <div className="text-xs text-gray-300 space-y-0.5">
                   {Object.entries(item.stats).map(([stat, value]) => (
                       <p key={stat}>+{value} {t(getStatTranslationKey(stat as StatKey))}</p>
                   ))}
               </div>
           </div>
       </div>
       <div className="mt-auto">
        {children}
       </div>
   </div>
);


const EquipmentModal: React.FC<EquipmentModalProps> = ({ player, onClose, onEquip, onUnequip, onUseConsumable, t }) => {
    const [activeTab, setActiveTab] = useState('equipment');
    const [selectedSlot, setSelectedSlot] = useState<EquipmentSlot | null>(null);
    
    const slots: EquipmentSlot[] = ['weapon', 'shield', 'helmet', 'armor', 'boots', 'necklace'];
    const slotIcons: Record<EquipmentSlot, string> = { weapon: '⚔️', shield: '🛡️', helmet: '⛑️', armor: '🎽', boots: '👢', necklace: '💍' };
    
    const statIcons: Record<StatKey, string> = { 
        vitality: '❤️‍🔥', attack: '⚔️', magicAttack: '✨', defense: '🛡️', magicDefense: '🔮', speed: '💨',  precision: '👁️', luck: '🍀', 
        critChance: '🎯', absorptionChance: '🌀', critMultiplier: '💥', absorptionReduction: '🛡️', maxHp: '❤️'
    };
    
    const primaryStats: { key: StatKey, icon: string }[] = useMemo(() => {
        const stats: { key: StatKey, icon: string }[] = [];
        stats.push({ key: 'vitality', icon: statIcons.vitality });
        stats.push({ key: 'luck', icon: statIcons.luck });
        if (player.attackType === 'physical' || player.baseMagicAttack < player.attack) {
            stats.push({ key: 'attack', icon: statIcons.attack });
        }
        if (player.baseMagicAttack > 0) {
            stats.push({ key: 'magicAttack', icon: statIcons.magicAttack });
        }
        stats.push({ key: 'defense', icon: statIcons.defense });
        stats.push({ key: 'magicDefense', icon: statIcons.magicDefense });
        stats.push({ key: 'speed', icon: statIcons.speed });
        stats.push({ key: 'precision', icon: statIcons.precision });
        return stats;
    }, [player.attackType, player.baseMagicAttack, player.attack]);

    const secondaryStats: { key: StatKey, icon: string, isPercent: boolean, isMultiplier?: boolean }[] = [
        { key: 'critChance', icon: statIcons.critChance, isPercent: true },
        { key: 'absorptionChance', icon: statIcons.absorptionChance, isPercent: true },
        { key: 'critMultiplier', icon: statIcons.critMultiplier, isPercent: false, isMultiplier: true },
        { key: 'absorptionReduction', icon: statIcons.absorptionReduction, isPercent: true },
    ];
    
    const allStats = [...primaryStats, ...secondaryStats];
    const displayStats = allStats.slice(0, 10); // Take the first 10 for the 5x2 grid

    const getTooltipStyle = (): React.CSSProperties => ({
        position: 'absolute', top: '100%', bottom: 'auto', marginTop: '10px',
        zIndex: 100, left: '50%', transform: 'translateX(-50%)'
    });
    
    const renderItemSelection = () => {
        if (!selectedSlot) return null;
        const itemsForSlot = player.inventory.filter(i => i.slot === selectedSlot);
        const equippedItem = player.equipment[selectedSlot];

        return (
            <div className='flex flex-col gap-4 animate-fade-in'>
                <div className='flex items-center gap-4 border-b border-gray-600 pb-3 mb-2'>
                    <button onClick={() => setSelectedSlot(null)} className='px-4 py-2 bg-gray-600 text-white font-bold rounded-lg hover:bg-gray-500 transition-colors'>{t('back')}</button>
                    <h3 className='text-2xl font-bold text-yellow-300'>{t('selectItem')} - {t(selectedSlot)}</h3>
                </div>
                <div className='grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 max-h-[45vh] overflow-y-auto p-2 bg-gray-900/50 rounded-lg'>
                    {equippedItem && (
                        <div>
                            <ItemCard item={equippedItem} t={t}>
                               <button onClick={() => { onUnequip(equippedItem); setSelectedSlot(null); }} className="w-full mt-2 px-4 py-2 bg-red-600 text-white font-bold rounded-lg text-sm hover:bg-red-500 transition-all text-center">
                                    Desequipar
                               </button>
                            </ItemCard>
                        </div>
                    )}
                    {itemsForSlot.map(item => (
                        <button onClick={() => { onEquip(item); setSelectedSlot(null); }} key={item.id} className="text-left h-full">
                           <ItemCard item={item} t={t}>
                               <div className="w-full mt-2 px-4 py-2 bg-blue-600 text-white font-bold rounded-lg text-sm hover:bg-blue-500 transition-all text-center">
                                    Equipar
                               </div>
                           </ItemCard>
                        </button>
                    ))}
                    {itemsForSlot.length === 0 && !equippedItem && (
                        <p className="text-gray-400 text-center col-span-full py-8">Nenhum item para este espaço no inventário.</p>
                    )}
                </div>
            </div>
        );
    };

    const renderEquipmentGrid = () => (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 animate-fade-in">
            {slots.map((slot) => {
                const item = player.equipment[slot];
                const hasNewItemInInventory = player.inventory.some(invItem => invItem.slot === slot && invItem.isNew);
                return (
                    <button key={slot} onClick={() => setSelectedSlot(slot)} className="flex flex-col items-center justify-center bg-gray-700/50 p-4 rounded-lg h-36 hover:bg-gray-700 transition-colors">
                         <div className="tooltip">
                            <div className={`relative w-20 h-20 bg-gray-900/50 rounded-lg flex items-center justify-center text-4xl border-2 ${item ? RARITY_BORDER_COLORS[item.rarity] : 'border-gray-600'}`}>
                                {item ? item.icon : <span className="filter grayscale opacity-50 text-4xl">{slotIcons[slot]}</span>}
                                {(item?.isNew || hasNewItemInInventory) && <div className="absolute -top-1.5 -right-1.5 w-4 h-4 bg-red-500 rounded-full border-2 border-gray-900 animate-pulse"></div>}
                            </div>
                            {item && (
                                 <div className="tooltiptext !w-60" style={getTooltipStyle()}>
                                    <p className={`font-bold text-lg ${RARITY_COLORS[item.rarity]}`}>{item.name}</p>
                                    <div className="text-left text-sm mt-2 space-y-1">
                                        {Object.entries(item.stats).map(([stat, value]) => (
                                            <p key={stat}>+{value} {t(getStatTranslationKey(stat as StatKey))}</p>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </div>
                        <p className="mt-2 font-semibold text-gray-300">{t(slot)}</p>
                    </button>
                );
            })}
        </div>
    );
    
    const allItemsInBackpack = useMemo(() => {
        const equippedIds = new Set(Object.values(player.equipment).map(i => i?.id));
        const inventoryWithEquippedStatus = player.inventory.map(item => ({...item, isEquipped: false}));
        const equippedWithEquippedStatus = Object.values(player.equipment)
            .filter((item): item is EquipmentItem => !!item)
            .map(item => ({...item, isEquipped: true}));

        const combined = [...inventoryWithEquippedStatus, ...equippedWithEquippedStatus];
        const uniqueItems = Array.from(new Map(combined.map(item => [item.id, item])).values());
        return uniqueItems.sort((a,b) => (a.isEquipped ? -1 : 1) - (b.isEquipped ? -1 : 1) || b.cost - a.cost);
    }, [player.inventory, player.equipment]);

    return (
      <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 animate-modal-fade-in">
        <div className="bg-gray-800 rounded-2xl border-2 border-yellow-400 p-6 shadow-lg max-w-3xl w-full flex flex-col">
            <div className="flex justify-center border-b-2 border-yellow-500 mb-4">
                <button onClick={() => { setActiveTab('equipment'); setSelectedSlot(null); }} className={`px-6 py-2 text-xl font-bold transition-colors ${activeTab === 'equipment' ? 'text-yellow-300 border-b-2 border-yellow-300' : 'text-gray-400 hover:text-yellow-200'}`}>{t('equipment')}</button>
                <button onClick={() => { setActiveTab('attributes'); setSelectedSlot(null); }} className={`px-6 py-2 text-xl font-bold transition-colors ${activeTab === 'attributes' ? 'text-yellow-300 border-b-2 border-yellow-300' : 'text-gray-400 hover:text-yellow-200'}`}>{t('attributes')}</button>
                <button onClick={() => { setActiveTab('backpack'); setSelectedSlot(null); }} className={`px-6 py-2 text-xl font-bold transition-colors ${activeTab === 'backpack' ? 'text-yellow-300 border-b-2 border-yellow-300' : 'text-gray-400 hover:text-yellow-200'}`}>{t('backpack')}</button>
            </div>
            
            <div className="w-full min-h-[60vh] max-h-[60vh] overflow-y-auto pr-2">
                {activeTab === 'equipment' && (
                    selectedSlot ? renderItemSelection() : renderEquipmentGrid()
                )}

                {activeTab === 'attributes' && (
                    <div className="animate-fade-in">
                          <div className="flex items-center space-x-3 bg-gray-700/50 p-3 rounded-lg mb-4">
                              <span className="text-2xl">❤️</span>
                              <div className="flex-grow">
                                  <span className="text-sm font-bold text-gray-300">{t('statLife')}</span>
                                  <p className='text-lg font-semibold text-white'>{`${Math.round(player.hp)} / ${Math.round(player.maxHp)}`}</p>
                              </div>
                          </div>
                          <div className="grid grid-cols-2 gap-3">
                              {displayStats.map(statInfo => {
                                  const value = (player as any)[statInfo.key];
                                  let displayValue;
                                  if ((statInfo as any).isPercent) {
                                      displayValue = `${(value * 100).toFixed(2)}%`;
                                  } else if ((statInfo as any).isMultiplier) {
                                      displayValue = `x${(1 + value).toFixed(2)}`;
                                  } else {
                                      displayValue = Math.round(value);
                                  }

                                  return (
                                    <div key={statInfo.key} className="flex items-center space-x-3 bg-gray-700/50 p-3 rounded-lg h-20">
                                        <span className="text-2xl">{statInfo.icon}</span>
                                        <div className="flex-grow">
                                            <span className="text-sm font-bold text-gray-300">{t(getStatTranslationKey(statInfo.key))}</span>
                                            <p className='text-lg font-semibold text-white'>{displayValue}</p>
                                        </div>
                                    </div>
                                  );
                              })}
                          </div>
                    </div>
                )}
                
                {activeTab === 'backpack' && (
                    <div className="animate-fade-in">
                        <h3 className="text-xl font-bold text-yellow-200 mb-3">Consumíveis</h3>
                        <div className="flex items-center gap-3 mb-6">
                            {Object.values(player.consumables).length > 0 ? (
                                Object.values(player.consumables).map(({item, quantity}) => {
                                    const isHealPotion = item.effect.type === 'HEAL_HP';
                                    const isDisabled = isHealPotion && player.hp >= player.maxHp;
                                    return (
                                        <div key={item.id} className="tooltip">
                                            <button 
                                                onClick={() => onUseConsumable(item)} 
                                                disabled={isDisabled}
                                                className={`relative flex items-center justify-center w-16 h-16 bg-gray-800 rounded-lg border-2 border-purple-400 hover:bg-purple-900/50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed disabled:saturate-50`}
                                            >
                                                <span className="text-3xl">{item.icon}</span>
                                                <span className="absolute -bottom-2 -right-2 bg-purple-600 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center border-2 border-gray-900">{quantity}</span>
                                            </button>
                                            <div className="tooltiptext !w-48 !-ml-24">
                                                <p className="font-bold">{item.name}</p>
                                                <p className="text-xs">{item.description}</p>
                                                {isDisabled && <p className="text-xs text-red-400 mt-1">Vida cheia!</p>}
                                            </div>
                                        </div>
                                    )
                                })
                            ) : (
                                <p className="text-gray-400">Nenhum consumível.</p>
                            )}
                        </div>
                        
                        <h3 className="text-xl font-bold text-yellow-200 mb-3">Itens</h3>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                            {allItemsInBackpack.length > 0 ? (
                                allItemsInBackpack.map(item => (
                                    <ItemCard key={item.id} item={item} t={t} isEquipped={item.isEquipped}>
                                        <button 
                                          onClick={() => item.isEquipped ? onUnequip(item) : onEquip(item)}
                                          className={`w-full mt-2 px-4 py-2 text-white font-bold rounded-lg text-sm transition-all text-center ${item.isEquipped ? 'bg-red-600 hover:bg-red-500' : 'bg-blue-600 hover:bg-blue-500'}`}
                                        >
                                            {item.isEquipped ? "Desequipar" : "Equipar"}
                                        </button>
                                    </ItemCard>
                                ))
                            ) : (
                                <p className="text-gray-400 col-span-full text-center py-4">Nenhum item.</p>
                            )}
                        </div>
                    </div>
                )}
            </div>
            
            <div className="mt-6 flex justify-center">
                <button onClick={onClose} className="px-8 py-3 bg-red-600 text-white font-bold rounded-lg hover:bg-red-500 transition-all">{t('close')}</button>
            </div>
        </div>
      </div>
    );
};
export default EquipmentModal;
